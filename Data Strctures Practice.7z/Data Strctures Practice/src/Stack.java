
public class Stack {
	int MAX_SIZE;
	int topOfStack;
	int stackArray[];
	
	public Stack(int max) {
		MAX_SIZE = max;
		topOfStack = -1;
		stackArray = new int[MAX_SIZE];
	}
	
	public void push(int val) {
		if(topOfStack == MAX_SIZE) {
			System.out.println("Stack is full");
		}else {
			topOfStack++;
			stackArray[topOfStack] = val;
		}
	}
	
	public int pop() {
		if(topOfStack != -1) {
			int val = stackArray[topOfStack];
			topOfStack--;
			return val;
		}else {
			System.out.println("Stack is empty");
			return -1; //handle error
		}
	}
	
	public int peek() {
		if(topOfStack != -1) {
			return stackArray[topOfStack];
		}else {
			System.out.println("Stack is empty");
			return -1; //handle error
		}
	}
	
	public int getSize() { return topOfStack+1; }
}
