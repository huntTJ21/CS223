
public class Program {

	public static void main(String[] args) {
		
	}
	
	public static void queueTest() {
		Queue testQ = new Queue();
		
		testQ.enqueue(1);
		testQ.enqueue(19);
		testQ.enqueue(42);
		//| 1|19|42|  |  |
		testQ.enqueue(27);
		//| 1|19|42|27|  |
		testQ.enqueue(85);
		//| 1|19|42|27|85|
		System.out.println(testQ.dequeue());
		//|  |19|42|27|  |
		testQ.enqueue(49);
		//|49|19|42|27|85|
		System.out.println(testQ.dequeue());
		//|49|  |42|27|85|
	}
	
	public static void stackTest() {
		Stack testS = new Stack(5);
	}

}
