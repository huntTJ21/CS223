
public class Queue {
	int MAX_SIZE;
	int front;
	int rear;
	int currSize;
	int queueArray[];
	
	public Queue(int max) {
		MAX_SIZE = max;
		front = 0;
		rear = 0;
		currSize = 0;
		queueArray = new int[MAX_SIZE];
	}
	
	public void enqueue(int val) {
		if(currSize == this.MAX_SIZE) {
			System.out.println("Queue is full");
		}else {
			queueArray[rear] = val;
			rear++;
			currSize++;
			if(rear == MAX_SIZE) {
				rear = 0;
			}
		}
	}
	
	public int dequeue() {
		if(currSize == 0) {
			System.out.println("Queue is empty");
			return -1; //handle error
		}else {
			int val = queueArray[front];
			front++;
			currSize--;
			if(front == MAX_SIZE) {
				front = 0;
			}
			return val;
		}
	}
	
	public int peek() {
		if(currSize == 0) {
			System.out.println("Queue is empty");
			return -1; //handle error
		}else {
			return queueArray[front];
		}
	}
	
	public int getSize() { return currSize; }
}
